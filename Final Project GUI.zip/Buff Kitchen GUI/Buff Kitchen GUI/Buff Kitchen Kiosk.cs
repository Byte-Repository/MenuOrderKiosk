﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Buff_Kitchen_GUI
{


    public partial class Buff_Kitchen_Kiosk : Form
    {

        public static string user { get; protected set; }


        public Buff_Kitchen_Kiosk()
        {
            InitializeComponent();
            listBox_menu.SelectionMode = SelectionMode.MultiExtended;
            listBox_order.SelectionMode = SelectionMode.MultiExtended;
        }

        double Cost = 0;
        string Order = null;
        public double CalculateTotalCost(string input, bool Total)
        {
            if (Total == true)
            {
                switch (input)
                {
                    case "Chicken Sandwhich":
                        Cost += 5.99;
                        break;
                    case "Chicken Nuggets":
                        Cost += 8.99;
                        break;
                    case "Chicken Strips":
                        Cost += 9.99;
                        break;
                    case "Beef Burger":
                        Cost += 6.99;
                        break;
                    case "Iced Tea":
                        Cost += 2.99;
                        break;
                    case "Soda":
                        Cost += 1.99;
                        break;
                    case "Lemonade":
                        Cost += 2.99;
                        break;
                    case "Coffee":
                        Cost += 3.99;
                        break;
                    case "Potato Fries":
                        Cost += 3.99;
                        break;
                    case "Salad":
                        Cost += 4.99;
                        break;
                    case "Fruit Cup":
                        Cost += 9.99;
                        break;
                    case "Potato Chips":
                        Cost += 2.99;
                        break;
                    //=====
                    default:
                        Cost += 5.99;
                        break;
                }
            }
            else
            {
                switch (input)
                {
                    case "Chicken Sandwhich":
                        Cost -= 5.99;
                        break;
                    case "Chicken Nuggets":
                        Cost -= 8.99;
                        break;
                    case "Chicken Strips":
                        Cost -= 9.99;
                        break;
                    case "Beef Burger":
                        Cost -= 6.99;
                        break;
                    case "Iced Tea":
                        Cost -= 2.99;
                        break;
                    case "Soda":
                        Cost -= 1.99;
                        break;
                    case "Lemonade":
                        Cost -= 2.99;
                        break;
                    case "Coffee":
                        Cost -= 3.99;
                        break;
                    case "Potato Fries":
                        Cost -= 3.99;
                        break;
                    case "Salad":
                        Cost -= 4.99;
                        break;
                    case "Fruit Cup":
                        Cost -= 9.99;
                        break;
                    case "Potato Chips":
                        Cost -= 2.99;
                        break;
                    //====
                    default:
                        Cost -= 5.99;
                        break;

                }
            }
            return Cost;

        }



        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {

        }

        private void listBox_menu_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label_cashier_Click(object sender, EventArgs e)
        {

        }


        private void textBox_name_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_logout_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Are you sure you want to logout?", "Logout", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                //if yes, hide this form
                this.Hide();
                Form_login fl = new Form_login();
                //show login window
                fl.Show();
            }
        }

        private void button_entrees_Click(object sender, EventArgs e)
        {
            listBox_menu.Items.Clear();
            listBox_menu.Items.Add("[Chicken Sandwich, 5.99]");
            listBox_menu.Items.Add("[Chicken Nuggets, 8.99]");
            listBox_menu.Items.Add("[Chicken Strips, 9.99]");
            listBox_menu.Items.Add("[Beef Burger, 6.99]");
        }


        private void button_drinks_Click(object sender, EventArgs e)
        {
            listBox_menu.Items.Clear();
            listBox_menu.Items.Add("[Iced Tea, 2.99]");
            listBox_menu.Items.Add("[Soda, 1.99]");
            listBox_menu.Items.Add("[Lemonade, 2.99]");
            listBox_menu.Items.Add("[Coffee, 3.99]");
        }

        private void button_sides_Click(object sender, EventArgs e)
        {
            listBox_menu.Items.Clear();
            listBox_menu.Items.Add("[Potato Fries, 3.99]");
            listBox_menu.Items.Add("[Salad, 4.99]");
            listBox_menu.Items.Add("[Fruit Cup, 9.99]");
            listBox_menu.Items.Add("[Potato Chips, 2.99]");
        }


        private void button_add_Click(object sender, EventArgs e)
        {


            if (listBox_menu.SelectedItems.Count > 0)
            {
                for (int i = 0; i < listBox_menu.SelectedItems.Count; i++)
                {
                    listBox_order.Items.Add(listBox_menu.SelectedItems[i].ToString());
                    Order += listBox_menu.SelectedItems[i].ToString() + " ; ";
                    label5.Text = (CalculateTotalCost(listBox_menu.SelectedItems[i].ToString(), true)).ToString();
                }
            }
        }

        private void listBox_submitted_SelectedIndexChanged(object sender, EventArgs e)
        {

        }



        private void button_submit_Click(object sender, EventArgs e)
        {
            
            //if the listbox & textbox is empty prompt a warning
            if (listBox_order.Text == null)
            {
                MessageBox.Show("Please select an item to order.");
                return;
            }
            if (textBox_name.Text == "")
            {
                MessageBox.Show("Empty customer name or order.");
                return;
            }
            else
            {
                
                listBox_submitted.Items.Add(textBox_name.Text + ": " + Order + "Total cost: " + Cost);
                MessageBox.Show("Order Added. " + Environment.NewLine + "Total: " + Cost);
                textBox_name.Clear();
                listBox_order.Items.Clear();
                label5.Text = "0.00";
                return;

            }
        }

        private void button_remove_Click(object sender, EventArgs e)
        {


                if (listBox_order.SelectedItems.Count > 0)
            {
                int j = listBox_order.SelectedItems.Count;
                for (int i = 0; i < j; i++)
                {
                    listBox_order.Items.Remove(listBox_order.SelectedItem);
                    label5.Text = (CalculateTotalCost(listBox_menu.SelectedItem.ToString(), false)).ToString();
                }
                
               
            }
        }


        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button_finish_Click(object sender, EventArgs e)
        {
     
            var result = MessageBox.Show("Are you sure to finish selected order?", "Finish", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                //if yes, clear selected order
                while (listBox_submitted.SelectedItems.Count > 0)
                {
                    listBox_submitted.Items.Remove(listBox_submitted.SelectedItems[0]);
                }
            }
        }

        private void Buff_Kitchen_Kiosk_Load(object sender, EventArgs e)
        {
            if(Form_login.login_url != null)
            {
                label_cashier.Text = Form_login.login_url;
            }
            
        }
    }
}
