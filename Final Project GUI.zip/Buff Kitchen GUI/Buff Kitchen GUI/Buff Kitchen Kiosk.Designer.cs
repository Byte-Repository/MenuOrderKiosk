﻿namespace Buff_Kitchen_GUI
{
    partial class Buff_Kitchen_Kiosk
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.button_logout = new System.Windows.Forms.Button();
            this.label_cashier = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_name = new System.Windows.Forms.TextBox();
            this.button_entrees = new System.Windows.Forms.Button();
            this.button_drinks = new System.Windows.Forms.Button();
            this.button_sides = new System.Windows.Forms.Button();
            this.button_add = new System.Windows.Forms.Button();
            this.button_submit = new System.Windows.Forms.Button();
            this.button_remove = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button_finish = new System.Windows.Forms.Button();
            this.listBox_menu = new System.Windows.Forms.ListBox();
            this.listBox_order = new System.Windows.Forms.ListBox();
            this.listBox_submitted = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(12, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cashier:";
            // 
            // button_logout
            // 
            this.button_logout.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_logout.Location = new System.Drawing.Point(436, 12);
            this.button_logout.Name = "button_logout";
            this.button_logout.Size = new System.Drawing.Size(86, 33);
            this.button_logout.TabIndex = 1;
            this.button_logout.Text = "Logout";
            this.button_logout.UseVisualStyleBackColor = true;
            this.button_logout.Click += new System.EventHandler(this.button_logout_Click);
            // 
            // label_cashier
            // 
            this.label_cashier.AutoSize = true;
            this.label_cashier.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_cashier.Location = new System.Drawing.Point(155, 16);
            this.label_cashier.Name = "label_cashier";
            this.label_cashier.Size = new System.Drawing.Size(0, 25);
            this.label_cashier.TabIndex = 2;
            this.label_cashier.Click += new System.EventHandler(this.label_cashier_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(82, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(137, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Customer Name";
            // 
            // textBox_name
            // 
            this.textBox_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_name.Location = new System.Drawing.Point(279, 87);
            this.textBox_name.Name = "textBox_name";
            this.textBox_name.Size = new System.Drawing.Size(145, 20);
            this.textBox_name.TabIndex = 4;
            this.textBox_name.TextChanged += new System.EventHandler(this.textBox_name_TextChanged);
            // 
            // button_entrees
            // 
            this.button_entrees.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_entrees.Location = new System.Drawing.Point(17, 138);
            this.button_entrees.Name = "button_entrees";
            this.button_entrees.Size = new System.Drawing.Size(81, 31);
            this.button_entrees.TabIndex = 5;
            this.button_entrees.Text = "Entrees";
            this.button_entrees.UseVisualStyleBackColor = true;
            this.button_entrees.Click += new System.EventHandler(this.button_entrees_Click);
            // 
            // button_drinks
            // 
            this.button_drinks.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_drinks.Location = new System.Drawing.Point(17, 175);
            this.button_drinks.Name = "button_drinks";
            this.button_drinks.Size = new System.Drawing.Size(81, 31);
            this.button_drinks.TabIndex = 6;
            this.button_drinks.Text = "Drinks";
            this.button_drinks.UseVisualStyleBackColor = true;
            this.button_drinks.Click += new System.EventHandler(this.button_drinks_Click);
            // 
            // button_sides
            // 
            this.button_sides.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_sides.Location = new System.Drawing.Point(17, 212);
            this.button_sides.Name = "button_sides";
            this.button_sides.Size = new System.Drawing.Size(81, 27);
            this.button_sides.TabIndex = 7;
            this.button_sides.Text = "Sides";
            this.button_sides.UseVisualStyleBackColor = true;
            this.button_sides.Click += new System.EventHandler(this.button_sides_Click);
            // 
            // button_add
            // 
            this.button_add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_add.Location = new System.Drawing.Point(17, 257);
            this.button_add.Name = "button_add";
            this.button_add.Size = new System.Drawing.Size(81, 53);
            this.button_add.TabIndex = 8;
            this.button_add.Text = "Add To Order";
            this.button_add.UseVisualStyleBackColor = false;
            this.button_add.Click += new System.EventHandler(this.button_add_Click);
            // 
            // button_submit
            // 
            this.button_submit.BackColor = System.Drawing.Color.Maroon;
            this.button_submit.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_submit.ForeColor = System.Drawing.SystemColors.Control;
            this.button_submit.Location = new System.Drawing.Point(17, 343);
            this.button_submit.Name = "button_submit";
            this.button_submit.Size = new System.Drawing.Size(197, 30);
            this.button_submit.TabIndex = 9;
            this.button_submit.Text = "SUBMIT";
            this.button_submit.UseVisualStyleBackColor = false;
            this.button_submit.Click += new System.EventHandler(this.button_submit_Click);
            // 
            // button_remove
            // 
            this.button_remove.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_remove.Location = new System.Drawing.Point(305, 280);
            this.button_remove.Name = "button_remove";
            this.button_remove.Size = new System.Drawing.Size(185, 30);
            this.button_remove.TabIndex = 10;
            this.button_remove.Text = "Remove From Order";
            this.button_remove.UseVisualStyleBackColor = true;
            this.button_remove.Click += new System.EventHandler(this.button_remove_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(326, 339);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 24);
            this.label4.TabIndex = 11;
            this.label4.Text = "Total:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(413, 339);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 24);
            this.label5.TabIndex = 12;
            this.label5.Text = "0.00";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Yellow;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Maroon;
            this.label6.Location = new System.Drawing.Point(170, 424);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(164, 25);
            this.label6.TabIndex = 13;
            this.label6.Text = "Pending Order";
            // 
            // button_finish
            // 
            this.button_finish.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button_finish.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_finish.Location = new System.Drawing.Point(12, 641);
            this.button_finish.Name = "button_finish";
            this.button_finish.Size = new System.Drawing.Size(510, 45);
            this.button_finish.TabIndex = 14;
            this.button_finish.Text = "Finish";
            this.button_finish.UseVisualStyleBackColor = false;
            this.button_finish.Click += new System.EventHandler(this.button_finish_Click);
            // 
            // listBox_menu
            // 
            this.listBox_menu.FormattingEnabled = true;
            this.listBox_menu.Location = new System.Drawing.Point(127, 138);
            this.listBox_menu.Name = "listBox_menu";
            this.listBox_menu.Size = new System.Drawing.Size(158, 199);
            this.listBox_menu.TabIndex = 15;
            this.listBox_menu.SelectedIndexChanged += new System.EventHandler(this.listBox_menu_SelectedIndexChanged);
            // 
            // listBox_order
            // 
            this.listBox_order.FormattingEnabled = true;
            this.listBox_order.HorizontalScrollbar = true;
            this.listBox_order.Location = new System.Drawing.Point(305, 138);
            this.listBox_order.Name = "listBox_order";
            this.listBox_order.Size = new System.Drawing.Size(185, 134);
            this.listBox_order.TabIndex = 16;
            // 
            // listBox_submitted
            // 
            this.listBox_submitted.FormattingEnabled = true;
            this.listBox_submitted.Location = new System.Drawing.Point(12, 452);
            this.listBox_submitted.Name = "listBox_submitted";
            this.listBox_submitted.Size = new System.Drawing.Size(505, 173);
            this.listBox_submitted.TabIndex = 17;
            this.listBox_submitted.SelectedIndexChanged += new System.EventHandler(this.listBox_submitted_SelectedIndexChanged);
            // 
            // Buff_Kitchen_Kiosk
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(534, 698);
            this.Controls.Add(this.listBox_submitted);
            this.Controls.Add(this.listBox_order);
            this.Controls.Add(this.listBox_menu);
            this.Controls.Add(this.button_finish);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button_remove);
            this.Controls.Add(this.button_submit);
            this.Controls.Add(this.button_add);
            this.Controls.Add(this.button_sides);
            this.Controls.Add(this.button_drinks);
            this.Controls.Add(this.button_entrees);
            this.Controls.Add(this.textBox_name);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label_cashier);
            this.Controls.Add(this.button_logout);
            this.Controls.Add(this.label1);
            this.Name = "Buff_Kitchen_Kiosk";
            this.Text = "Buff Kitchen Kiosk";
            this.Load += new System.EventHandler(this.Buff_Kitchen_Kiosk_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_logout;
        private System.Windows.Forms.Label label_cashier;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_name;
        private System.Windows.Forms.Button button_entrees;
        private System.Windows.Forms.Button button_drinks;
        private System.Windows.Forms.Button button_sides;
        private System.Windows.Forms.Button button_add;
        private System.Windows.Forms.Button button_submit;
        private System.Windows.Forms.Button button_remove;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button_finish;
        private System.Windows.Forms.ListBox listBox_menu;
        private System.Windows.Forms.ListBox listBox_order;
        private System.Windows.Forms.ListBox listBox_submitted;
    }
}