﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Buff_Kitchen_GUI
{
    

    public partial class Form_login : Form
    {
        //Cashier names will be called from here
        public static string login_url = "";
        
        public Form_login()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }


        private void button_login_Click(object sender, EventArgs e)
        {
            

            if (textBox_cashier.Text ==""|| textBox_password.Text =="")
            {
                MessageBox.Show("Empty cashier name or password");
                return;
            }
            try
            {
                //connection string, it is the path/value used to find the database.
                string connectionString = @"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=|DataDirectory|\Kitchen.mdf;Integrated Security = True";

                //Create SQL conection
                SqlConnection con = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand("Select * from login where cashier = @cashier and password = @password", con);

                //Assing values to variables
                cmd.Parameters.AddWithValue("@cashier", textBox_cashier.Text);
                cmd.Parameters.AddWithValue("@password", textBox_password.Text);

                //open connection to DB
                con.Open();

                //select records from database and populate
                SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();

                //Add rows in data adapter
                adapt.Fill(ds);

                //Close connection
                con.Close();

                //get collection of tables 
                int count = ds.Tables[0].Rows.Count;

                //if count is equal to 1 that means the SQL query get the record.
                if (count == 1)
                {
                    MessageBox.Show("Login Successful!");
                    //Assign login_url to cashiers' name
                    login_url = textBox_cashier.Text;
                    this.Hide();
                    Buff_Kitchen_Kiosk fm = new Buff_Kitchen_Kiosk();
                    fm.Show();
                }
                else
                {
                    MessageBox.Show("Login Failed: Could Not Find Your Account!");
                }

            }
            //catch trow out error message if there is one
            catch (Exception ex)
            { 
                //show the error message
                MessageBox.Show(ex.Message);
            }
            //=============================================================
        }

        private void textBox_cashier_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
